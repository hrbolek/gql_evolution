@pytest_asyncio.fixture
async def db_session(tmp_path):
    db_file = tmp_path / "test.sqlite3"
    connection_string = f"sqlite+aiosqlite:///{db_file}"

    session_maker = await startEngine(
        connection_string,
        makeDrop=True,
        makeUp=True,
    )

    assert session_maker is not None, "Unable to create async session maker"

    async with session_maker() as session:
        await init_database_data(session)
        yield session

    remove = getattr(session_maker, "remove", None)
    if remove is not None:
        result = remove()
        if hasattr(result, "__await__"):
            await result